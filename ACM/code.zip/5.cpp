/***
x�������ϣ������a���յ�b��3�ֲ�����
1. x=x*2
2. x=x+1
3. x=x-1

2->4 x=x*2
2->5 x*2  x+1
*/
#include<bits/stdc++.h>
using namespace std;
int a,b;
struct node {
    int x,step;
    node(int _a,int _b){x=_a,step=_b;}
};
int bfs()
{
    queue<node> q;
    q.push(node(a,0));
    while(!q.empty()){
        node f=q.front();
        q.pop();
        if(f.x==b) return f.step;
        q.push(node(f.x*2,f.step+1));
        q.push(node(f.x+1,f.step+1));
        q.push(node(f.x-1,f.step+1));
    }
}
int main()
{
    cin>>a>>b;
    cout<<bfs();

    return 0;
}

